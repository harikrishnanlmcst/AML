from flask import Flask, render_template, request, redirect
from flask_mysqldb import MySQL

app = Flask(__name__, template_folder='template')

# Configure MySQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Hari@2001'
app.config['MYSQL_DB'] = 'aml'

mysql = MySQL(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['POST'])
def register():
    if request.method == 'POST':
        userDetails = request.form
        userType = userDetails['user-type']

        if userType == 'bank':
            BankId = userDetails['bank-id']
            Name = userDetails['bank-name']
            Branch = userDetails['bank-branch']
            Address = userDetails['bank-address']
            ContactNumber = userDetails['bank-contact-number']
            Email = userDetails['bank-email']
            UserName = userDetails['bank-username']
            Password = userDetails['bank-password']

            cur = mysql.connection.cursor()
            cur.execute("INSERT INTO aml_bankdetails (`bank-id`, `bank-name`, `bank-branch`, `bank-address`, `bank-contactnumber`, `bank-emailid`, `bank-username`, `bank-password`) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                        (BankId, Name, Branch, Address, ContactNumber, Email, UserName, Password))
            mysql.connection.commit()
            cur.close()

            return redirect('/success')  # Redirect to success page after registration

    return 'Registration failed. Please try again.'  # If the form data is not valid or user type is invalid

@app.route('/success')
def success():
    return 'Registration successful'

if __name__ == '__main__':
    app.run(debug=True)
